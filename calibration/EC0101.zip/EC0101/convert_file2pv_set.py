from pathlib import Path

BASE_DIR = Path.cwd()

CHANNEL_FILES = {
    "A": "Channel-A.txt",
    "B": "Channel-B.txt",
    "C": "Channel-C.txt",
    "D": "Channel-D.txt",
}

# 0 -> 10mA
# 1 -> 1mA
# 2 -> 100uA
# 3 -> 10uA
# 4 -> 1uA
# 5 -> 100nA
RANGE_NAMES = {
    0: "10mA",
    1: "1mA",
    2: "100uA",
    3: "10uA",
    4: "1uA",
    5: "100nA",
}


def read_calibration_file(filename):
    """
    File format:
        range,gain,offset

    Example:
        0,523277,1010
        1,523270,1017
        2,523259,1028
        3,523222,1065
        4,523231,1056
        5,523234,1053
    """

    data = {}

    with open(filename, "r") as f:
        for line in f:
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            fields = line.split(",")

            if len(fields) != 3:
                raise ValueError(
                    f"Invalid line in {filename}: {line}"
                )

            range_index = int(fields[0].strip())
            gain = int(fields[1].strip())
            offset = int(fields[2].strip())

            if range_index not in RANGE_NAMES:
                raise ValueError(
                    f"Invalid range {range_index} in {filename}"
                )

            data[range_index] = {
                # Gain must be negative
                "gain": -abs(gain),
                "offset": offset,
            }

    # Make sure all 6 ranges exist
    for range_index in RANGE_NAMES:
        if range_index not in data:
            raise ValueError(
                f"Range {range_index} missing in {filename}"
            )

    return data


def generate_calibration(directory):

    # Example: EC0102
    serial_number = directory.name

    print(f"Processing {serial_number} ...")

    calibration = {}

    # -----------------------------------------------------
    # Read Channel-A.txt ~ Channel-D.txt
    # -----------------------------------------------------

    for channel, filename in CHANNEL_FILES.items():

        input_file = directory / filename

        if not input_file.exists():
            raise FileNotFoundError(
                f"Missing file: {input_file}"
            )

        calibration[channel] = read_calibration_file(input_file)

    # -----------------------------------------------------
    # Generate EPICS commands
    # -----------------------------------------------------

    output = []

    output.append(
        "##########################################################"
    )
    output.append(
        f"# Calibration for NSLS2 Electrometer: serial number {serial_number}"
    )
    output.append(
        "##########################################################"
    )
    output.append("")

    for range_index, range_name in RANGE_NAMES.items():

        output.append(
            f"# Calibration for {range_name} range"
        )

        # Gain: Channel A, B, C, D
        for channel in ["A", "B", "C", "D"]:

            gain = calibration[channel][range_index]["gain"]

            output.append(
                f"dbpf ${{PREFIX}}Ch{channel}-{range_name}-Gain-SP {gain}"
            )

        # Offset: Channel A, B, C, D
        for channel in ["A", "B", "C", "D"]:

            offset = calibration[channel][range_index]["offset"]

            output.append(
                f"dbpf ${{PREFIX}}Ch{channel}-{range_name}-Ofst-SP {offset}"
            )

        output.append("")

    result = "\n".join(output)

    # -----------------------------------------------------
    # Output file:
    #
    # EC0102 -> EC0102/EC0102.cmd
    # EC0103 -> EC0103/EC0103.cmd
    # ...
    # -----------------------------------------------------

    output_file = directory / f"{serial_number}.cmd"

    output_file.write_text(result + "\n")

    print(f"  -> Saved: {output_file}")


# =========================================================
# MAIN
# =========================================================

for number in range(101, 124):

    # 102 -> EC0102
    # 103 -> EC0103
    # ...
    # 123 -> EC0123
    serial_number = f"EC{number:04d}"

    directory = BASE_DIR / serial_number

    # Directory does not exist
    if not directory.is_dir():
        print(f"SKIP: {serial_number}: directory not found")
        continue

    try:
        generate_calibration(directory)

    except FileNotFoundError as e:
        # Example: Channel-D.txt missing
        print(f"SKIP: {serial_number}: {e}")

    except Exception as e:
        print(f"ERROR: {serial_number}: {e}")


print("Done.")
