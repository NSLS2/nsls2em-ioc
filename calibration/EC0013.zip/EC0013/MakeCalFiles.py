A = [line.strip('\n') for line in open("Channel A.txt","r")]
B = [line.strip('\n') for line in open("Channel B.txt","r")]
C = [line.strip('\n') for line in open("Channel C.txt","r")]
D = [line.strip('\n') for line in open("Channel D.txt","r")]

Ga = []
Gb = []
Gc = []
Gd = []

Oa = []
Ob = []
Oc = []
Od = []

for i in range(0,len(A)):
    Adat = [int(z) for z in A[i].split(',')]
    if(len(Adat)==3):
        Ga.append(abs(Adat[1]))
        Oa.append(Adat[2])
    Bdat = [int(z) for z in B[i].split(',')]
    if(len(Bdat)==3):
        Gb.append(abs(Bdat[1]))
        Ob.append(Bdat[2])
    Cdat = [int(z) for z in C[i].split(',')]
    if(len(Cdat)==3):
        Gc.append(abs(Cdat[1]))
        Oc.append(Cdat[2])
    Ddat = [int(z) for z in D[i].split(',')]
    if(len(Ddat)==3):
        Gd.append(abs(Ddat[1]))
        Od.append(Ddat[2])

f10mA = open("Range10mA.txt","w")
f1mA = open("Range1mA.txt","w")
f100uA = open("Range100uA.txt","w")
f10uA = open("Range10uA.txt","w")
f1uA = open("Range1uA.txt","w")
f100nA = open("Range100nA.txt","w")

f10mA.write("10mA,Gain,Offset\n")
f10mA.write("A,"+str(Ga[0])+","+str(Oa[0])+"\n")
f10mA.write("B,"+str(Gb[0])+","+str(Ob[0])+"\n")
f10mA.write("C,"+str(Gc[0])+","+str(Oc[0])+"\n")
f10mA.write("D,"+str(Gd[0])+","+str(Od[0])+"\n")
f10mA.close()

f1mA.write("1mA,Gain,Offset\n")
f1mA.write("A,"+str(Ga[1])+","+str(Oa[1])+"\n")
f1mA.write("B,"+str(Gb[1])+","+str(Ob[1])+"\n")
f1mA.write("C,"+str(Gc[1])+","+str(Oc[1])+"\n")
f1mA.write("D,"+str(Gd[1])+","+str(Od[1])+"\n")
f1mA.close()

f100uA.write("100uA,Gain,Offset\n")
f100uA.write("A,"+str(Ga[2])+","+str(Oa[2])+"\n")
f100uA.write("B,"+str(Gb[2])+","+str(Ob[2])+"\n")
f100uA.write("C,"+str(Gc[2])+","+str(Oc[2])+"\n")
f100uA.write("D,"+str(Gd[2])+","+str(Od[2])+"\n")
f100uA.close()

f10uA.write("10uA,Gain,Offset\n")
f10uA.write("A,"+str(Ga[3])+","+str(Oa[3])+"\n")
f10uA.write("B,"+str(Gb[3])+","+str(Ob[3])+"\n")
f10uA.write("C,"+str(Gc[3])+","+str(Oc[3])+"\n")
f10uA.write("D,"+str(Gd[3])+","+str(Od[3])+"\n")
f10uA.close()

f1uA.write("1uA,Gain,Offset\n")
f1uA.write("A,"+str(Ga[4])+","+str(Oa[4])+"\n")
f1uA.write("B,"+str(Gb[4])+","+str(Ob[4])+"\n")
f1uA.write("C,"+str(Gc[4])+","+str(Oc[4])+"\n")
f1uA.write("D,"+str(Gd[4])+","+str(Od[4])+"\n")
f1uA.close()

f100nA.write("100nA,Gain,Offset\n")
f100nA.write("A,"+str(Ga[5])+","+str(Oa[5])+"\n")
f100nA.write("B,"+str(Gb[5])+","+str(Ob[5])+"\n")
f100nA.write("C,"+str(Gc[5])+","+str(Oc[5])+"\n")
f100nA.write("D,"+str(Gd[5])+","+str(Od[5])+"\n")
f100nA.close()
