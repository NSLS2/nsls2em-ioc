from pathlib import Path

# ---------------------------------------------------------
# NSLS2 Electrometer Calibration File Generator
# ---------------------------------------------------------

SERIAL_NUMBER = "EC0005"

# Input files
channel_files = {
    "A": "Channel-A.txt",
    "B": "Channel-B.txt",
    "C": "Channel-C.txt",
    "D": "Channel-D.txt",
}

# Range index -> EPICS range name
range_names = {
    0: "10mA",
    1: "1mA",
    2: "100uA",
    3: "10uA",
    4: "1uA",
    5: "100nA",
}


def read_calibration_file(filename):
    """
    Read calibration file.

    Expected format:
        range,gain,offset

    Example:
        0,523277,1010
        1,523270,1017
        2,523259,1028
        3,523222,1065
        4,523231,1056
        5,523234,1053
    """
    data = {}

    with open(filename, "r") as f:
        for line in f:
            line = line.strip()

            # Ignore blank lines and comments
            if not line or line.startswith("#"):
                continue

            fields = line.split(",")

            if len(fields) != 3:
                raise ValueError(
                    f"Invalid line in {filename}: {line}"
                )

            range_index = int(fields[0].strip())
            gain = int(fields[1].strip())
            offset = int(fields[2].strip())

            if range_index not in range_names:
                raise ValueError(
                    f"Invalid range {range_index} in {filename}"
                )

            data[range_index] = {
                # Gain must be negative
                "gain": -abs(gain),
                "offset": offset,
            }

    return data


# ---------------------------------------------------------
# Read all four channel files
# ---------------------------------------------------------

calibration = {}

for channel, filename in channel_files.items():
    calibration[channel] = read_calibration_file(filename)


# ---------------------------------------------------------
# Generate EPICS dbpf commands
# ---------------------------------------------------------

output = []

output.append("##########################################################")
output.append(
    f"# Calibration for NSLS2 Electrometer: serial number {SERIAL_NUMBER}"
)
output.append("##########################################################")
output.append("")

for range_index, range_name in range_names.items():

    output.append(f"# Calibration for {range_name} range")

    # Gain
    for channel in ["A", "B", "C", "D"]:
        gain = calibration[channel][range_index]["gain"]

        output.append(
            f"dbpf ${{PREFIX}}Ch{channel}-{range_name}-Gain-SP {gain}"
        )

    # Offset
    for channel in ["A", "B", "C", "D"]:
        offset = calibration[channel][range_index]["offset"]

        output.append(
            f"dbpf ${{PREFIX}}Ch{channel}-{range_name}-Ofst-SP {offset}"
        )

    output.append("")


# ---------------------------------------------------------
# Print result
# ---------------------------------------------------------

result = "\n".join(output)

print(result)


# ---------------------------------------------------------
# Optional: save result
# ---------------------------------------------------------

output_filename = f"calibration_{SERIAL_NUMBER}.cmd"

Path(output_filename).write_text(result + "\n")

print(f"\nSaved: {output_filename}")

